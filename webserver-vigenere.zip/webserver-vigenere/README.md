Webserver to Break and Encrypt/Decrypt using Vigenere Cipher
Segurança Computacional - UnB
Prof.: João Gondim


Felipe Nascimento Rocha - 170/0050084
Jônatas Gomes Barbosa da Silva - 170059847


Compilação Linux

````
python -m venv venv
. venv/bin/activate
pip install -r requirements.txt
flask --app flaskr --debug run
````

Compilação Windows
````
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
flask --app flaskr --debug run
````



Listen on:
````
127.0.0.1:5000
````
